﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SolutionStudio.BuildingBlocks.Application.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.Commands;
using SolutionStudio.Modules.DataProducts.Application.Queries;
using SolutionStudio.Modules.DataProducts.Facade.RequestModels.DataProduct;
using SolutionStudio.Modules.DataProducts.Facade.ResponseModels.DataProduct;

namespace SolutionStudio.Modules.DataProducts.Facade.Controllers;

[ApiController]
[Authorize]
[SuppressMessage("Roslynator", "RCS1046:Asynchronous method name should end with \'Async\'")]
public sealed class DataProductController : ControllerBase
{
    [HttpGet("dataProducts")]
    public async Task<IReadOnlyList<DataProductHeaderResponseModel>> GetDataProducts(
        [FromServices] IQueryHandler<GetDataProductsQuery, GetDataProductsQuery.Response> queryHandler)
    {
        var response = await queryHandler.HandleQueryAsync(new GetDataProductsQuery());

        return response.DataProducts
            .Select(ds => new DataProductHeaderResponseModel
            {
                DataProductId = ds.DataProductId.ToString(),
                Name = ds.Name,
                ApiName = ds.ApiName,
                Title = ds.Title,
                Description = ds.Description,
                Purpose = ds.Purpose,
                TagLine = ds.TagLine,
                Synonyms = ds.Synonyms,
                ObjectType = ds.ObjectType,
                Category = ds.Category,
                Tags = ds.Tags,
                BoId = ds.BoId,
                Url = ds.Url,
                UiActn = ds.UiActn
            })
            .ToArray();
    }

    [HttpGet("dataProducts/{dataProductId}")]
    public async Task<DataProductResponseModel> GetDataProduct(
        string dataProductId,
        [FromServices] IQueryHandler<GetDataProductQuery, GetDataProductQuery.Response> queryHandler
    )
    {
        var queryResponse = await queryHandler.HandleQueryAsync(new GetDataProductQuery
        {
            DataProductId = dataProductId
        });
        var dataProduct = queryResponse.DataProduct;

        return new DataProductResponseModel
        {
            DataProductId = dataProduct.DataProductId,
            Name = dataProduct.Name,
            ApiName = dataProduct.ApiName,
            Title = dataProduct.Title,
            Description = dataProduct.Description,
            Purpose = dataProduct.Purpose,
            TagLine = dataProduct.TagLine,
            Synonyms = dataProduct.Synonyms,
            ObjectType = dataProduct.ObjectType,
            Category = dataProduct.Category,
            Tags = dataProduct.Tags,
            BoId = dataProduct.BoId,
            Url = dataProduct.Url,
            UiActn = dataProduct.UiActn,
            Parameters = dataProduct.Parameters,
            Fields = dataProduct.Fields
                .Select(f => new DataProductFieldResponseModel
                {
                    FieldId = f.FieldId,
                    Name = f.Name,
                    ApiName = f.ApiName,
                    FriendlyName = f.FriendlyName,
                    Description = f.Description,
                    FieldType = f.FieldType,
                    Collection = f.Collection,
                    Group = f.Group,
                    DataType = f.DataType,
                    Priority = f.Priority,
                    SemanticTags = f.SemanticTags,
                    ShareWithAssistant = f.ShareWithAssistant,
                    DisableShare = f.DisableShare,
                    UiActn = f.UiActn
                })
                .ToArray(),
            Actions = dataProduct.Actions,
            Governance = dataProduct.Governance
        };
    }

    [HttpPost("dataProducts")]
    public async Task<NewDataProductResponseModel> CreateDataProduct(
        [FromBody] NewDataProductRequestModel requestModel,
        [FromServices] ICommandHandler<CreateDataProductCommand, CreateDataProductCommand.Response> commandHandler)
    {
        var command = new CreateDataProductCommand
        {
            Name = requestModel.Name
        };

        var response = await commandHandler.HandleCommandAsync(command);

        return new NewDataProductResponseModel
        {
            DataProductId = response.DataProductId,
            Name = "Created" // todo: change
        };
    }
}

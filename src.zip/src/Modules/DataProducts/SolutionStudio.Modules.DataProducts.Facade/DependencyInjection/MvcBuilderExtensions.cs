using System.Reflection;

namespace Microsoft.Extensions.DependencyInjection;

public static class MvcBuilderExtensions
{
    public static IMvcBuilder AddDataProductsModuleControllers(this IMvcBuilder builder)
    {
        builder.AddApplicationPart(Assembly.GetAssembly(typeof(MvcBuilderExtensions))!);

        return builder;
    }
}

﻿using System.ComponentModel.DataAnnotations;
using SolutionStudio.BuildingBlocks.Facade.RequestModels;

namespace SolutionStudio.Modules.DataProducts.Facade.RequestModels.DataProduct;

public sealed record NewDataProductRequestModel
{
    [StringLength(FieldLengthLimit.Short)]
    public required string Name { get; init; }
}

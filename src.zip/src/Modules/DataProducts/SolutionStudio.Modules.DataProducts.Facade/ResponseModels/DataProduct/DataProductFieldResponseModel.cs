﻿namespace SolutionStudio.Modules.DataProducts.Facade.ResponseModels.DataProduct;

public sealed record DataProductFieldResponseModel
{
    public required string FieldId { get; init; }
    public required string Name { get; init; }
    public required string ApiName { get; init; }
    public required string FriendlyName { get; init; }
    public required string Description { get; init; }
    public required string FieldType { get; init; } // todo: enum?
    public required string Collection { get; init; }
    public required string Group { get; init; }
    public required string DataType { get; init; }
    public required string Priority { get; init; } // todo: string or int?
    public required string[] SemanticTags { get; init; }
    public required bool ShareWithAssistant { get; init; }
    public required bool DisableShare { get; init; } // todo: IsSharingEnabled
    public required string UiActn { get; init; } // todo: avoid abbreviations
}

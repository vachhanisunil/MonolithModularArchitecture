﻿namespace SolutionStudio.Modules.DataProducts.Facade.ResponseModels.DataProduct;

public sealed record DataProductResponseModel
{
    public required string DataProductId { get; init; }
    public required string Name { get; init; }
    public required string ApiName { get; init; }
    public required string Title { get; init; }
    public required string Description { get; init; }
    public required string Purpose { get; init; }
    public required string TagLine { get; init; }
    public required string Synonyms { get; init; }
    public required string ObjectType { get; init; }
    public required string Category { get; init; }
    public required string[] Tags { get; init; }
    public required string[] BoId { get; init; } // todo: avoid abbreviations
    public required string Url { get; init; }
    public required string UiActn { get; init; } // todo: avoid abbreviations
    public required string[] Parameters { get; init; }
    public required DataProductFieldResponseModel[] Fields { get; init; }
    public required string[] Actions { get; init; }
    public required string[] Governance { get; init; }
}

namespace SolutionStudio.Modules.DataProducts.Facade.ResponseModels.DataProduct;

public sealed record NewDataProductResponseModel
{
    public required Guid DataProductId { get; init; }
    public required string Name { get; init; }
}

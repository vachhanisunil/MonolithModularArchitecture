using Microsoft.Extensions.Configuration;
using SolutionStudio.Modules.DataProducts.Application.Abstractions.Repositories;
using SolutionStudio.Modules.DataProducts.Infrastructure.Repositories;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDataProductsModuleInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        _ = configuration;
        services.AddScopedWithMongoDatabase<IDataProductRepository, DataProductRepository>();

        return services;
    }
}

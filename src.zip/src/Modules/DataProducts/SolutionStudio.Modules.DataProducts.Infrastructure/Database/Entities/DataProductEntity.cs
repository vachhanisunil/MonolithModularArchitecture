﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SolutionStudio.Modules.DataProducts.Infrastructure.Database.Entities;

internal sealed record DataProductEntity
{
    public const string CollectionName = "dataproducts.dataproducts";

    [BsonId]
    public ObjectId Id { get; set; }

    [BsonElement]
    public required Guid DataProductId { get; init; }

    [BsonElement]
    public required string CreationUserName { get; init; }

    [BsonElement]
    public required DateTime CreationDateTime { get; init; }

    [BsonElement]
    public required string Name { get; init; }

    [BsonElement]
    public required string ApiName { get; init; }

    [BsonElement]
    public required string Title { get; init; }

    [BsonElement]
    public required string Description { get; init; }

    [BsonElement]
    public required string Purpose { get; init; }

    [BsonElement]
    public required string TagLine { get; init; }

    [BsonElement]
    public required string Synonyms { get; init; }

    [BsonElement]
    public required string ObjectType { get; init; }

    [BsonElement]
    public required string Category { get; init; }

    [BsonElement]
    public required string[] Tags { get; init; }
}

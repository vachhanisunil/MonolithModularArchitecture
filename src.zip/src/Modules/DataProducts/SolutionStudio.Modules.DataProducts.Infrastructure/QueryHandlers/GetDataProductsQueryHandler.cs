﻿using Microsoft.Extensions.Logging;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Application.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.Abstractions.Repositories;
using SolutionStudio.Modules.DataProducts.Application.Queries;
using SolutionStudio.Modules.DataProducts.Application.QueryModels;

namespace SolutionStudio.Modules.DataProducts.Infrastructure.QueryHandlers;

internal sealed class GetDataProductsQueryHandler : IQueryHandler<GetDataProductsQuery, GetDataProductsQuery.Response>
{
    private readonly ILogger<GetDataProductsQueryHandler> _logger;
    private readonly IUserContext _userContext;
    private readonly IDataProductRepository _dataProductRepository;

    public GetDataProductsQueryHandler(
        ILogger<GetDataProductsQueryHandler> logger,
        IUserContext userContext,
        IDataProductRepository dataProductRepository
    )
    {
        _logger = logger;
        _userContext = userContext;
        _dataProductRepository = dataProductRepository;
    }

    public async Task<GetDataProductsQuery.Response> HandleQueryAsync(GetDataProductsQuery query)
    {
        _logger.LogDebug("Retrieving data products requested by user '{UserName}'", _userContext.UserName);

        var dataProducts = await _dataProductRepository.GetDataProductsAsync();

        var queryResponse = new GetDataProductsQuery.Response
        {
            DataProducts = dataProducts
                .Select(dp => new DataProductHeaderQueryModel
                {
                    DataProductId = dp.DataProductId,
                    Name = dp.Name,
                    ApiName = dp.ApiName,
                    Title = dp.Title,
                    Description = dp.Description,
                    Purpose = dp.Purpose,
                    TagLine = dp.TagLine,
                    Synonyms = dp.Synonyms,
                    ObjectType = dp.ObjectType,
                    Category = dp.Category,
                    Tags = [],
                    BoId = [],
                    Url = "",
                    UiActn = "",
                })
                .ToArray(),
            Dictionaries =
            [
                new DataProductDictionaryQueryModel
                {
                    Group = "Some group"
                }
            ]
        };

        return queryResponse;
    }
}

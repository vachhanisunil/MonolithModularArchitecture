﻿using Microsoft.Extensions.Logging;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Application.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.Queries;
using SolutionStudio.Modules.DataProducts.Application.QueryModels;

namespace SolutionStudio.Modules.DataProducts.Infrastructure.QueryHandlers;

internal sealed class GetDataProductQueryHandler : IQueryHandler<GetDataProductQuery, GetDataProductQuery.Response>
{
    private readonly ILogger<GetDataProductsQueryHandler> _logger;
    private readonly IUserContext _userContext;

    public GetDataProductQueryHandler(
        ILogger<GetDataProductsQueryHandler> logger,
        IUserContext userContext)
    {
        _logger = logger;
        _userContext = userContext;
    }

    public Task<GetDataProductQuery.Response> HandleQueryAsync(GetDataProductQuery query)
    {
        _logger.LogDebug("Retrieving data product '{DataProductId}' requested by user '{UserName}'", query.DataProductId, _userContext.UserName);

        const string dataProductName = "CMDF_CLAIMS_LIST_ADM";

        var dataProduct = new DataProductQueryModel
        {
            DataProductId = Guid.NewGuid()
                .ToString(),
            Name = dataProductName,
            ApiName = dataProductName,
            Title = dataProductName,
            Description = dataProductName,
            Purpose = "",
            TagLine = "",
            Synonyms = "",
            ObjectType = "V4",
            Category = "Data Product",
            Tags =
            [
            ],
            BoId =
            [
            ],
            Url = "",
            UiActn = "",
            Parameters =
            [
            ],
            Fields =
            [
                new DataProductFieldQueryModel
                {
                    FieldId = "TRPRS",
                    Name = "TRPRS",
                    ApiName = "TRPRS",
                    FriendlyName = "Processing Status",
                    Description = "Current stage of approval",
                    FieldType = "A",
                    Collection = "A",
                    Group = "",
                    DataType = "string",
                    Priority = "2",
                    SemanticTags =
                    [
                        "claim",
                        "status"
                    ],
                    ShareWithAssistant = false,
                    DisableShare = false,
                    UiActn = ""
                }
            ],
            Actions =
            [
            ],
            Governance =
            [
            ]
        };

        var queryResponse = new GetDataProductQuery.Response
        {
            DataProduct = dataProduct,
            Dictionaries =
            [
                new DataProductDictionaryQueryModel { Group = "Some group" }
            ]
        };

        return Task.FromResult(queryResponse);
    }
}

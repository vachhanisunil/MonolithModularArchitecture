﻿using MongoDB.Driver;
using SolutionStudio.BuildingBlocks.Application.Exceptions;
using SolutionStudio.Modules.DataProducts.Application.Abstractions.Repositories;
using SolutionStudio.Modules.DataProducts.Application.Models;
using SolutionStudio.Modules.DataProducts.Infrastructure.Database.Entities;

namespace SolutionStudio.Modules.DataProducts.Infrastructure.Repositories;

internal sealed class DataProductRepository : IDataProductRepository
{
    private readonly IMongoDatabase _mongoDatabase;

    public DataProductRepository(IMongoDatabase mongoDatabase)
    {
        _mongoDatabase = mongoDatabase;
    }

    public async Task<IReadOnlyCollection<DataProductHeader>> GetDataProductsAsync()
    {
        var collection = _mongoDatabase.GetCollection<DataProductEntity>(DataProductEntity.CollectionName);

        var dataProductEntities = await collection
            .Find(_ => true)
            .SortByDescending(x => x.Name)
            .Project(dp => new
            {
                dp.DataProductId,
                dp.CreationUserName,
                dp.CreationDateTime,
                dp.Name,
                dp.ApiName,
                dp.Title,
                dp.Description,
                dp.Purpose,
                dp.TagLine,
                dp.Synonyms,
                dp.ObjectType,
                dp.Category
            })
            .ToListAsync();

        return dataProductEntities
            .Select(dp => new DataProductHeader
            {
                DataProductId = dp.DataProductId,
                CreationUserName = dp.CreationUserName,
                CreationDateTime = dp.CreationDateTime,
                Name = dp.Name,
                ApiName = dp.ApiName,
                Title = dp.Title,
                Description = dp.Description,
                Purpose = dp.Purpose,
                TagLine = dp.TagLine,
                Synonyms = dp.Synonyms,
                ObjectType = dp.ObjectType,
                Category = dp.Category
            })
            .ToArray();
    }

    public async Task<DataProduct> GetDataProductAsync(Guid dataProductId)
    {
        var collection = _mongoDatabase.GetCollection<DataProductEntity>(DataProductEntity.CollectionName);

        var dataProductEntity = await collection
            .Find(x => x.DataProductId == dataProductId)
            .SingleOrDefaultAsync();

        if (dataProductEntity is null)
        {
            throw new SolutionStudioNotFoundException($"Data Product `{dataProductId}` could not be found.");
        }

        return MapToModel(dataProductEntity);
    }

    public async Task CreateDataProductAsync(DataProduct dataProduct)
    {
        var collection = _mongoDatabase.GetCollection<DataProductEntity>(DataProductEntity.CollectionName);

        var dataProductEntity = MapToEntity(dataProduct);

        await collection.InsertOneAsync(dataProductEntity);
    }

    private static DataProductEntity MapToEntity(DataProduct dataProduct)
    {
        return new DataProductEntity
        {
            DataProductId = dataProduct.DataProductId,
            CreationUserName = dataProduct.CreationUserName,
            CreationDateTime = dataProduct.CreationDateTime,
            Name = dataProduct.Name,
            ApiName = dataProduct.ApiName,
            Title = dataProduct.Title,
            Description = dataProduct.Description,
            Purpose = dataProduct.Purpose,
            TagLine = dataProduct.TagLine,
            Synonyms = dataProduct.Synonyms,
            ObjectType = dataProduct.ObjectType,
            Category = dataProduct.Category,
            Tags = dataProduct.Tags
        };
    }

    private static DataProduct MapToModel(DataProductEntity entity)
    {
        return new DataProduct
        {
            DataProductId = entity.DataProductId,
            CreationUserName = entity.CreationUserName,
            CreationDateTime = entity.CreationDateTime,
            Name = entity.Name,
            ApiName = entity.ApiName,
            Title = entity.Title,
            Description = entity.Description,
            Purpose = entity.Purpose,
            TagLine = entity.TagLine,
            Synonyms = entity.Synonyms,
            ObjectType = entity.ObjectType,
            Category = entity.Category,
            Tags = entity.Tags
        };
    }
}

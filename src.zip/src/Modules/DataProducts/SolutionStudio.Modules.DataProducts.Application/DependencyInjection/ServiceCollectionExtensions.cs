﻿namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDataProductsModuleApplication(this IServiceCollection services)
    {
        return services;
    }
}

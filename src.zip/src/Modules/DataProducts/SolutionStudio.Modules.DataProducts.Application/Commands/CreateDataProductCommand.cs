﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

namespace SolutionStudio.Modules.DataProducts.Application.Commands;

public sealed record CreateDataProductCommand : ICommand<CreateDataProductCommand.Response>
{
    public required string Name { get; init; }

    public sealed record Response
    {
        public Guid DataProductId { get; init; }
    };
}

﻿namespace SolutionStudio.Modules.DataProducts.Application.QueryModels;

public sealed record DataProductDictionaryQueryModel
{
    public required string Group { get; init; }
}

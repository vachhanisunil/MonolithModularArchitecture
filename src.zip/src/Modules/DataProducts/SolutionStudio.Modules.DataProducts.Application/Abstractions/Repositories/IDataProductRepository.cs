﻿using SolutionStudio.Modules.DataProducts.Application.Models;

namespace SolutionStudio.Modules.DataProducts.Application.Abstractions.Repositories;

public interface IDataProductRepository
{
    Task<IReadOnlyCollection<DataProductHeader>> GetDataProductsAsync();
    Task<DataProduct> GetDataProductAsync(Guid dataProductId);
    Task CreateDataProductAsync(DataProduct dataProduct);
}

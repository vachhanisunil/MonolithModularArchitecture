﻿namespace SolutionStudio.Modules.DataProducts.Application.Models;

public sealed record DataProduct
{
    public required Guid DataProductId { get; init; }
    public required string CreationUserName { get; init; }
    public required DateTime CreationDateTime { get; init; }
    public required string Name { get; init; }
    public required string ApiName { get; init; }
    public required string Title { get; init; }
    public required string Description { get; init; }
    public required string Purpose { get; init; }
    public required string TagLine { get; init; }
    public required string Synonyms { get; init; }
    public required string ObjectType { get; init; }
    public required string Category { get; init; }
    public required string[] Tags { get; init; }
}

﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.QueryModels;

namespace SolutionStudio.Modules.DataProducts.Application.Queries;

public sealed record GetDataProductQuery : IQuery<GetDataProductQuery.Response>
{
    public required string DataProductId { get; init; }

    public sealed record Response
    {
        public required DataProductQueryModel DataProduct { get; init; }
        public required IReadOnlyCollection<DataProductDictionaryQueryModel> Dictionaries { get; init; }
    }
}

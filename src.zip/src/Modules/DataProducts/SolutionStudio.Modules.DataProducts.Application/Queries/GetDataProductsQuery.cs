﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.QueryModels;

namespace SolutionStudio.Modules.DataProducts.Application.Queries;

public sealed record GetDataProductsQuery : IQuery<GetDataProductsQuery.Response>
{
    public sealed record Response
    {
        public required IReadOnlyCollection<DataProductHeaderQueryModel> DataProducts { get; init; }
        public required IReadOnlyCollection<DataProductDictionaryQueryModel> Dictionaries { get; init; }
    }
}

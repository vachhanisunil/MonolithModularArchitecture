﻿using Microsoft.Extensions.Logging;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Application.Cqrs;
using SolutionStudio.Modules.DataProducts.Application.Abstractions.Repositories;
using SolutionStudio.Modules.DataProducts.Application.Commands;
using SolutionStudio.Modules.DataProducts.Application.Models;

namespace SolutionStudio.Modules.DataProducts.Application.CommandHandlers;

internal sealed class CreateDataProductCommandHandler : ICommandHandler<CreateDataProductCommand, CreateDataProductCommand.Response>
{
    private readonly ILogger<CreateDataProductCommandHandler> _logger;
    private readonly IUserContext _userContext;
    private readonly IDataProductRepository _dataProductRepository;

    public CreateDataProductCommandHandler(
        ILogger<CreateDataProductCommandHandler> logger,
        IUserContext userContext,
        IDataProductRepository dataProductRepository
    )
    {
        _logger = logger;
        _userContext = userContext;
        _dataProductRepository = dataProductRepository;
    }

    public async Task<CreateDataProductCommand.Response> HandleCommandAsync(CreateDataProductCommand command)
    {
        _logger.LogInformation("Creating data product '{DataProductName}' by user '{UserName}'", command.Name, _userContext.UserName);

        var dataProductId = Guid.NewGuid();

        var dataProduct = new DataProduct
        {
            DataProductId = dataProductId,
            CreationUserName = _userContext.UserName,
            CreationDateTime = DateTime.UtcNow,
            Name = command.Name,
            ApiName = command.Name, // todo: extend the command with more props
            Title = command.Name,
            Description = command.Name,
            Purpose = command.Name,
            TagLine = command.Name,
            Synonyms = command.Name,
            ObjectType = command.Name,
            Category = command.Name,
            Tags = []
        };

        await _dataProductRepository.CreateDataProductAsync(dataProduct);

        return new CreateDataProductCommand.Response
        {
            DataProductId = dataProductId,
        };
    }
}

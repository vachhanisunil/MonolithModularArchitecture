using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;
using Serilog;

const string corsPolicyName = "DefaultCorsPolicy";

var builder = WebApplication.CreateBuilder(args);

var isDevelopment = builder.Environment.EnvironmentName.StartsWith(Environments.Development, StringComparison.OrdinalIgnoreCase);

if (isDevelopment)
{
    builder.Configuration.Sources.Clear();
    builder.Configuration
        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
        .AddJsonFile("appsettings.Development.Base.json", optional: false, reloadOnChange: true)
        .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: false, reloadOnChange: true)
        .AddUserSecrets<Program>(optional: false, reloadOnChange: true)
        .AddCommandLine(args)
        .AddEnvironmentVariables();
}

// Modules setup =================================================

builder.Services.AddBuildingBlocksInfrastructure(builder.Configuration);
builder.Services.AddMongoDbInfrastructure(builder.Configuration);

builder.Services.AddDataProductsModuleApplication();
builder.Services.AddDataProductsModuleInfrastructure(builder.Configuration);

// Web application setup ==========================================

Serilog.Debugging.SelfLog.Enable(output => System.Console.WriteLine("Serilog: " + output));
builder.Services.AddSerilog((_, loggerConfiguration) => loggerConfiguration.ReadFrom.Configuration(builder.Configuration));

builder.Services.AddWebInfrastructure(builder.Configuration);
builder.Services.AddHealthChecks();
builder.Services.AddTelemetry(builder.Configuration);

builder.Services.AddHttpContextAccessor();

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto | ForwardedHeaders.XForwardedHost;

    // trust all proxies (required for Kubernetes)
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

builder.Services.AddAuthentication(builder.Configuration);
builder.Services.AddAuthorization(builder.Configuration);

builder.Services.AddControllers(options =>
    {
        options.AddFilters();
    })
    .AddDataProductsModuleControllers();

builder.Services.AddCors(builder.Configuration, corsPolicyName);

builder.Services.AddOpenApi(builder.Configuration);

var app = builder.Build();

app.UseForwardedHeaders();
app.UseHealthChecks("/health");

app.UseCors(corsPolicyName);

app.UseSerilogRequestLogging();

// Configure the HTTP request pipeline
app.MapOpenApi();
app.MapScalarApi(app.Configuration);

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using SolutionStudio.BuildingBlocks.Application.Exceptions;

namespace SolutionStudio.Applications.Infrastructure.Web.Filters;

public class ExceptionFilter : IExceptionFilter
{
    private readonly ILogger<ExceptionFilter> _logger;
    private readonly ProblemDetailsFactory _problemDetailsFactory;

    public ExceptionFilter(ILogger<ExceptionFilter> logger,
        ProblemDetailsFactory problemDetailsFactory)
    {
        _logger = logger;
        _problemDetailsFactory = problemDetailsFactory;
    }

    public void OnException(ExceptionContext context)
    {
        var exception = context.Exception;
        var httpContext = context.HttpContext;
        if (exception is SolutionStudioValidationException validationException)
        {
            _logger.LogWarning(validationException, "Validation error occurred.");
            var validationProblemDetails = _problemDetailsFactory.CreateProblemDetails(httpContext, statusCode: 400, title: validationException.Message);
            context.Result = new ObjectResult(validationProblemDetails)
            {
                StatusCode = validationProblemDetails.Status
            };
            context.ExceptionHandled = true;
            return;
        }

        if (exception is SolutionStudioAuthorizationException authorizationException)
        {
            _logger.LogWarning(authorizationException, "Authorization error occurred.");
            var authorizationProblemDetails = _problemDetailsFactory.CreateProblemDetails(httpContext, statusCode: 403, title: authorizationException.Message);
            context.Result = new ObjectResult(authorizationProblemDetails)
            {
                StatusCode = authorizationProblemDetails.Status
            };
            context.ExceptionHandled = true;
            return;
        }

        if (exception is SolutionStudioNotFoundException notFoundException)
        {
            _logger.LogWarning(notFoundException, "Validation error occurred.");
            var validationProblemDetails = _problemDetailsFactory.CreateProblemDetails(httpContext, statusCode: 404, title: notFoundException.Message);
            context.Result = new ObjectResult(validationProblemDetails)
            {
                StatusCode = validationProblemDetails.Status
            };
            context.ExceptionHandled = true;
            return;
        }

        _logger.LogError(exception, "Internal API error occurred.");
        var problemDetails = _problemDetailsFactory.CreateProblemDetails(httpContext, statusCode: 500, title: "Internal API error occurred");
        context.Result = new ObjectResult(problemDetails)
        {
            StatusCode = problemDetails.Status
        };
        context.ExceptionHandled = true;
    }
}

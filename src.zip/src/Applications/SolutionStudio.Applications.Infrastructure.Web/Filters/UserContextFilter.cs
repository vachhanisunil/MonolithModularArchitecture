﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using SolutionStudio.Applications.Infrastructure.Web.Authentication;

namespace SolutionStudio.Applications.Infrastructure.Web.Filters;

internal sealed class UserContextFilter : IAsyncActionFilter
{
    private readonly ILogger<UserContextFilter> _logger;

    public UserContextFilter(ILogger<UserContextFilter> logger)
    {
        _logger = logger;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var userClaims = context.HttpContext.User.Claims.ToArray();
        var userName = userClaims.FirstOrDefault(c => c.Type == VistexUserClaimTypes.PreferredUsername)?.Value;
        if (userName is null)
        {
            await next();
            return;
        }

        using var _ = _logger.BeginScope(new Dictionary<string, string>
        {
            ["UserName"] = userName,
            ["Tenant"] = userClaims.FirstOrDefault(c => c.Type == VistexUserClaimTypes.Tenant)?.Value ?? string.Empty
        });

        _logger.LogInformation("Request for user '{UserName}' started. User claims: {UserClaims}",
            userName,
            string.Join("; ", userClaims.Select(c => $"{c.Type}: '{c.Value}'")));

        await next();
    }
}

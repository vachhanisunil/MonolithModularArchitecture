using SolutionStudio.Applications.Infrastructure.Web.Filters;

namespace Microsoft.AspNetCore.Mvc;

public static class MvcOptionsExtensions
{
    public static MvcOptions AddFilters(this MvcOptions options)
    {
        options.Filters.Add<ModelStateFilter>(1);
        options.Filters.Add<ExceptionFilter>(2);
        options.Filters.Add<UserContextFilter>(3);

        return options;
    }
}

using Microsoft.Extensions.Configuration;
using Scalar.AspNetCore;
using SolutionStudio.Applications.Infrastructure.Web.Settings;

namespace Microsoft.AspNetCore.Routing;

public static class EndpointRouteBuilderExtensions
{
    public static IEndpointRouteBuilder MapScalarApi(this IEndpointRouteBuilder app, IConfiguration configuration)
    {
        var authenticationSettings = configuration.GetRequiredSettingsFromSection<AuthenticationSettings>(AuthenticationSettings.ConfigurationSectionName);

        app.MapScalarApiReference("/docs", options =>
        {
            options
                .WithTitle("Solution Studio API")
                .WithTheme(ScalarTheme.Laserwave)
                .EnableDarkMode()
                .DisableDefaultFonts()
                .DisableAgent()
                .DisableMcp()
                .DisableTelemetry();

            if (authenticationSettings.OAuth is not null)
            {
                options.AddHttpAuthentication("bearer", _ => { });

                options.AddAuthorizationCodeFlow("oauth2", flow =>
                {
                    flow.ClientId = authenticationSettings.OpenApi.DefaultClientId;
                    flow.Pkce = Pkce.Sha256;
                    flow.SelectedScopes = new[] { authenticationSettings.OAuth.GetApiResourceScope() };
                });

                options
                    .AddPreferredSecuritySchemes("oauth2")
                    .EnablePersistentAuthentication();
            }
        });

        return app;
    }
}

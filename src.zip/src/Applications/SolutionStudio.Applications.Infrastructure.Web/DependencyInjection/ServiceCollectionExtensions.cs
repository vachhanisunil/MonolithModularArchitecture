﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi;
using SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;
using SolutionStudio.Applications.Infrastructure.Web.Authentication;
using SolutionStudio.Applications.Infrastructure.Web.Security;
using SolutionStudio.Applications.Infrastructure.Web.Security.Context;
using SolutionStudio.Applications.Infrastructure.Web.Settings;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;
using SolutionStudio.BuildingBlocks.Facade.Security.Authorization;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddWebInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        _ = configuration; // todo: remove
        services.AddScoped<IClaimsPrincipalAccessor, HttpContextClaimsPrincipalAccessor>();
        services.AddScoped<IUserContext, ClaimsPrincipalUserContext>();
        services.AddScoped<IUserTenantContext, ClaimsPrincipalUserContext>();
        services.AddScoped<IAdminUserContext, ClaimsPrincipalAdminUserContext>();
        services.AddScoped<IUserClaimContext, ClaimsPrincipalUserClaimContext>();

        return services;
    }

    public static IServiceCollection AddCors(this IServiceCollection services, IConfiguration configuration, string policyName)
    {
        return services.AddCors(options =>
        {
            options.AddPolicy(policyName, policyBuilder =>
            {
                var corsSettings = configuration.GetRequiredSettingsFromSection<CorsSettings>(CorsSettings.ConfigurationSectionName);
                policyBuilder
                    .WithOrigins([.. corsSettings.AllowedOrigins])
                    .WithHeaders(HeaderNames.Authorization, HeaderNames.Accept, HeaderNames.ContentType, HeaderNames.Origin, HeaderNames.CacheControl)
                    .WithExposedHeaders(HeaderNames.ContentDisposition)
                    .AllowAnyMethod()
                    .AllowCredentials();
            });
        });
    }

    public static AuthenticationBuilder AddAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var authenticationSettings = configuration.GetRequiredSettingsFromSection<AuthenticationSettings>(AuthenticationSettings.ConfigurationSectionName);
        var oAuthSettings = authenticationSettings.OAuth
            ?? throw new SolutionStudioConfigurationException("OAuth configuration is missing");

        return AddOAuthAuthentication(services, oAuthSettings);
    }

    public static IServiceCollection AddAuthorization(this IServiceCollection services, IConfiguration configuration)
    {
        return services.AddAuthorization(options =>
        {
            var tenants = configuration.GetTenants();

            var authorizationPolicyBuilder = new AuthorizationPolicyBuilder();
            authorizationPolicyBuilder.RequireAuthenticatedUser();
            authorizationPolicyBuilder.RequireClaim(VistexUserClaimTypes.Tenant, tenants);

            foreach (var requiredClaimType in ClaimsPrincipalUserContext.RequiredClaimTypes)
            {
                authorizationPolicyBuilder.RequireClaim(requiredClaimType);
            }

            var authorizationPolicy = authorizationPolicyBuilder.Build();

            options.AddPolicy(AuthorizationPolicies.TenantAuthorizationPolicy, authorizationPolicy);
            options.DefaultPolicy = authorizationPolicy;
        });
    }

    public static IServiceCollection AddOpenApi(this IServiceCollection services, IConfiguration configuration)
    {
        var authenticationSettings = configuration.GetRequiredSettingsFromSection<AuthenticationSettings>(AuthenticationSettings.ConfigurationSectionName);

        return services.AddOpenApi(options =>
        {
            options.AddDocumentTransformer((document, _, _) =>
            {
                // Overwrite server URLs as OpenApi ignores X-Forwarded headers and adds a URL starting with http instead of https
                document.Servers = [];
                return Task.CompletedTask;
            });

            options.AddDocumentTransformer((document, _, _) =>
            {
                document.Info.Title = "Solution Studio API";

                if (authenticationSettings.OAuth is not null)
                {
                    string issuerUrl = authenticationSettings.OAuth.IssuerUrl.TrimEnd('/');
                    string apiScope = authenticationSettings.OAuth.GetApiResourceScope();

                    document.Components ??= new OpenApiComponents();
                    document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>();

                    document.Components.SecuritySchemes.Add("oauth2", new OpenApiSecurityScheme
                    {
                        Type = SecuritySchemeType.OAuth2,
                        Flows = new OpenApiOAuthFlows
                        {
                            AuthorizationCode = new OpenApiOAuthFlow
                            {
                                AuthorizationUrl = new Uri($"{issuerUrl}/{authenticationSettings.OpenApi.AuthorizationEndpoint.TrimStart('/')}"),
                                TokenUrl = new Uri($"{issuerUrl}/{authenticationSettings.OpenApi.TokenEndpoint.TrimStart('/')}"),
                                Scopes = new Dictionary<string, string>
                                {
                                    { apiScope, "Access to Solution Studio API" }
                                }
                            }
                        }
                    });

                    document.Components.SecuritySchemes.Add("bearer", new OpenApiSecurityScheme
                    {
                        In = ParameterLocation.Header,
                        Type = SecuritySchemeType.Http,
                        Scheme = "Bearer",
                        BearerFormat = "JWT",
                        Description = "Enter a valid JWT token"
                    });

                    document.Security ??= [];
                    document.Security.Add(
                        new OpenApiSecurityRequirement
                        {
                            [new OpenApiSecuritySchemeReference("oauth2", document)] = [apiScope]
                        });
                    document.Security.Add(
                        new OpenApiSecurityRequirement
                        {
                            [new OpenApiSecuritySchemeReference("bearer", document)] = [apiScope]
                        });
                }

                return Task.CompletedTask;
            });
        });
    }

    public static IServiceCollection AddTelemetry(this IServiceCollection services, IConfiguration configuration)
    {
        var applicationInsightsSettings = configuration.GetSection(ApplicationInsightsSettings.ConfigurationSectionName)
            .Get<ApplicationInsightsSettings>();

        if (applicationInsightsSettings is not null && !string.IsNullOrWhiteSpace(applicationInsightsSettings.ConnectionString))
        {
            services.AddApplicationInsightsTelemetry(options =>
            {
                options.ConnectionString = applicationInsightsSettings.ConnectionString;
            });
        }

        return services;
    }

    private static AuthenticationBuilder AddOAuthAuthentication(IServiceCollection services, OAuthAuthenticationSettings oAuthSettings)
    {
        return services
            .AddAuthentication(SolutionStudioAuthenticationSchemes.OAuth)
            .AddJwtBearer(options =>
            {
                options.Audience = oAuthSettings.Audience;
                options.Authority = oAuthSettings.IssuerUrl;
            });
    }
}

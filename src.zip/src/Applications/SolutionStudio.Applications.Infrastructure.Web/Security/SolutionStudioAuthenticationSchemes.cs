﻿using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace SolutionStudio.Applications.Infrastructure.Web.Security;

public static class SolutionStudioAuthenticationSchemes
{
    public const string OAuth = JwtBearerDefaults.AuthenticationScheme;
}

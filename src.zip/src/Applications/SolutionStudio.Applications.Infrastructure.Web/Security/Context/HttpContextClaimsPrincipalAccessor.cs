﻿using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;
using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace SolutionStudio.Applications.Infrastructure.Web.Security.Context;

internal sealed class HttpContextClaimsPrincipalAccessor : IClaimsPrincipalAccessor
{
    private readonly ClaimsPrincipal _claimsPrincipal;

    public HttpContextClaimsPrincipalAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _claimsPrincipal = httpContextAccessor.HttpContext?.User
                           ?? throw new SolutionStudioInternalException("Could not get user identity from HttpContext.");
    }

    public ClaimsPrincipal GetClaimsPrincipal()
    {
        return _claimsPrincipal;
    }
}

﻿using System.Security.Claims;
using SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Facade.Security.Authorization;

namespace SolutionStudio.Applications.Infrastructure.Web.Security.Context;

internal sealed class ClaimsPrincipalAdminUserContext : IAdminUserContext
{
    private readonly ClaimsPrincipal _claimsPrincipal;

    public ClaimsPrincipalAdminUserContext(IClaimsPrincipalAccessor claimsPrincipalAccessor)
    {
        _claimsPrincipal = claimsPrincipalAccessor.GetClaimsPrincipal();
    }

    public bool IsTenantAdmin()
    {
        return _claimsPrincipal.IsInRole(AuthorizationRoles.TenantAdmin);
    }
}

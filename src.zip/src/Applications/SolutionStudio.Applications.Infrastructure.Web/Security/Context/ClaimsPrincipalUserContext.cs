using System.Security.Claims;
using SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;
using SolutionStudio.Applications.Infrastructure.Web.Authentication;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Abstractions.Models;

namespace SolutionStudio.Applications.Infrastructure.Web.Security.Context;

internal sealed class ClaimsPrincipalUserContext : IUserContext
{
    private readonly ClaimsPrincipal _claimsPrincipal;

    public static readonly IReadOnlyCollection<string> RequiredClaimTypes =
    [
        VistexUserClaimTypes.PreferredUsername,
        VistexUserClaimTypes.Name,
        VistexUserClaimTypes.ClientId,
        VistexUserClaimTypes.Tenant
    ];

    public ClaimsPrincipalUserContext(IClaimsPrincipalAccessor claimsPrincipalAccessor)
    {
        _claimsPrincipal = claimsPrincipalAccessor.GetClaimsPrincipal();
    }

    public string UserName => _claimsPrincipal.GetRequiredClaimValue(VistexUserClaimTypes.PreferredUsername);
    public string FullUserName => _claimsPrincipal.GetRequiredClaimValue(VistexUserClaimTypes.Name);
    public string? Email => _claimsPrincipal.FindFirstValue(VistexUserClaimTypes.Email);
    public string? Language => _claimsPrincipal.FindFirstValue(VistexUserClaimTypes.Language);
    public string ClientId => _claimsPrincipal.GetRequiredClaimValue(VistexUserClaimTypes.ClientId);
    public TenantIdentifier Tenant => _claimsPrincipal.GetRequiredClaimValue(VistexUserClaimTypes.Tenant);
}

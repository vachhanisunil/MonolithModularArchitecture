using System.Security.Claims;
using SolutionStudio.BuildingBlocks.Application.Exceptions;

namespace SolutionStudio.Applications.Infrastructure.Web.Security.Context;

internal static class ClaimsPrincipalExtensions
{
    internal static string GetRequiredClaimValue(this ClaimsPrincipal principal, string claimType)
    {
        var value = principal.FindFirstValue(claimType);

        if (value is null)
        {
            throw new SolutionStudioAuthorizationException($"Could not find required claim of type '{claimType}'");
        }

        return value;
    }

    internal static IReadOnlyCollection<string> GetClaimValues(this ClaimsPrincipal principal, string claimType)
    {
        var claims = principal.FindAll(claimType);

        return claims
                .Select(c => c.Value)
                .ToArray();
    }
}

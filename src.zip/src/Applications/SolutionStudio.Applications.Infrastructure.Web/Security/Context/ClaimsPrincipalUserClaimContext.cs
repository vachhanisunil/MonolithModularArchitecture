﻿using System.Security.Claims;
using SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;
using SolutionStudio.BuildingBlocks.Abstractions.Context;

namespace SolutionStudio.Applications.Infrastructure.Web.Security.Context;

internal sealed class ClaimsPrincipalUserClaimContext : IUserClaimContext
{
    private readonly ClaimsPrincipal _claimsPrincipal;

    public ClaimsPrincipalUserClaimContext(IClaimsPrincipalAccessor claimsPrincipalAccessor)
    {
        _claimsPrincipal = claimsPrincipalAccessor.GetClaimsPrincipal();
    }

    public string GetRequiredClaimValue(string claimType)
    {
        return _claimsPrincipal.GetRequiredClaimValue(claimType);
    }
}

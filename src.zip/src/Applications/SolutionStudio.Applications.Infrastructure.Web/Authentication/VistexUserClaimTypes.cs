﻿using System.Security.Claims;

namespace SolutionStudio.Applications.Infrastructure.Web.Authentication;

public static class VistexUserClaimTypes
{
    public const string PreferredUsername = "preferred_username";
    public const string Name = "name";
    public const string Email = ClaimTypes.Email;
    public const string GtmsUserId = "gtms_userid";
    public const string Language = "language";
    public const string ClientId = "client_id";
    public const string Tenant = "tenant";
}

﻿namespace SolutionStudio.Applications.Infrastructure.Web.Settings;

public sealed record OpenApiSettings
{
    public required string AuthorizationEndpoint { get; init; }
    public required string TokenEndpoint { get; init; }
    public required string DefaultClientId { get; init; }
}

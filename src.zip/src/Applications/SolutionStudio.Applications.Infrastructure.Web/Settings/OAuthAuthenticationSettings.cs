namespace SolutionStudio.Applications.Infrastructure.Web.Settings;

public sealed record OAuthAuthenticationSettings
{
    public required string IssuerUrl { get; init; }

    public required string Audience { get; init; } = "SolutionStudioApi";

    public string GetApiResourceScope() => Audience;
}

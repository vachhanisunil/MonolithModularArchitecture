﻿namespace SolutionStudio.Applications.Infrastructure.Web.Settings;

internal sealed record CorsSettings
{
    public const string ConfigurationSectionName = "Cors";

    public required IReadOnlyCollection<string> AllowedOrigins { get; init; } = [];
}

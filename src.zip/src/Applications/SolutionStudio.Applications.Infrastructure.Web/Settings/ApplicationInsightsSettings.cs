﻿namespace SolutionStudio.Applications.Infrastructure.Web.Settings;

internal sealed record ApplicationInsightsSettings
{
    public const string ConfigurationSectionName = "ApplicationInsights";

    public required string? ConnectionString { get; init; }
}

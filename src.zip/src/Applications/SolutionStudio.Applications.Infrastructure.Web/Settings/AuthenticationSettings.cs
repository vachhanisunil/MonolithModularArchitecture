namespace SolutionStudio.Applications.Infrastructure.Web.Settings;

public sealed record AuthenticationSettings
{
    public const string ConfigurationSectionName = "Authentication";

    public OAuthAuthenticationSettings? OAuth { get; init; }

    public required OpenApiSettings OpenApi { get; init; }
}

﻿using System.Security.Claims;

namespace SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;

internal interface IClaimsPrincipalAccessor
{
    ClaimsPrincipal GetClaimsPrincipal();
}

﻿using System.Security.Claims;

namespace SolutionStudio.Applications.Infrastructure.Web.Abstractions.Services;

internal interface IClaimsIdentityProvider
{
    Task<ClaimsIdentity?> GetClaimsIdentityAsync(ClaimsPrincipal principal);
}

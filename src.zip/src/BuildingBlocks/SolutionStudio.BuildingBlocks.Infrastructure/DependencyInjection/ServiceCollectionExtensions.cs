﻿using Microsoft.Extensions.Configuration;
using System.Reflection;
using SolutionStudio.BuildingBlocks.Abstractions.Services;
using SolutionStudio.BuildingBlocks.Application.Cqrs;
using SolutionStudio.BuildingBlocks.Infrastructure.Services;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddBuildingBlocksInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddCqrs();

        services.AddTenantsProvider(configuration);

        return services;
    }

    private static IServiceCollection AddTenantsProvider(this IServiceCollection services, IConfiguration configuration)
    {
        var tenants = configuration.GetTenants();
        return services.AddSingleton<ITenantsProvider>(new TenantsProvider(tenants));
    }

    private static IServiceCollection AddCqrs(this IServiceCollection services)
    {
        var assemblies = AppDomain.CurrentDomain.GetAssemblies();
        AddHandlers(services, assemblies, typeof(ICommandHandler<>));
        AddHandlers(services, assemblies, typeof(ICommandHandler<,>));
        AddHandlers(services, assemblies, typeof(IQueryHandler<,>));
        AddHandlers(services, assemblies, typeof(IEventHandler<>));
        return services;
    }

    private static void AddHandlers(IServiceCollection services, Assembly[] assemblies, Type handlerType)
    {
        services.Scan(s =>
            s.FromAssemblies(assemblies)
                .AddClasses(c => c.AssignableTo(handlerType).Where(t => !t.IsGenericType), false)
                .AsImplementedInterfaces()
                .WithTransientLifetime()
        );
    }
}

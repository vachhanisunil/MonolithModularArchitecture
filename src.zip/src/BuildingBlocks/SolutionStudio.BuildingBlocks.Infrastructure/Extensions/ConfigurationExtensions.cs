﻿using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace Microsoft.Extensions.Configuration;

public static class ConfigurationExtensions
{
    public static IReadOnlyCollection<string> GetTenants(this IConfiguration configuration)
    {
        const string tenantsSectionName = "Tenants";
        var tenantsSection = configuration.GetSection(tenantsSectionName);
        return tenantsSection.Get<IReadOnlyCollection<string>>() ?? [];
    }

    public static T? GetSettingsFromSection<T>(this IConfiguration configuration, string sectionName)
    {
        var moduleConfiguration = configuration.GetSection(sectionName);

        return moduleConfiguration.Get<T>(options => options.ErrorOnUnknownConfiguration = true);
    }

    public static T GetRequiredSettingsFromSection<T>(this IConfiguration configuration, string sectionName)
    {
        var moduleConfiguration = configuration.GetRequiredSection(sectionName);

        return moduleConfiguration.Get<T>(options => options.ErrorOnUnknownConfiguration = true)
               ?? throw new SolutionStudioConfigurationException($"Invalid configuration section '{sectionName}'");
    }
}

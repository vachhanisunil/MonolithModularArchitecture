﻿using SolutionStudio.BuildingBlocks.Abstractions.Models;
using SolutionStudio.BuildingBlocks.Abstractions.Services;

namespace SolutionStudio.BuildingBlocks.Infrastructure.Services;

internal sealed class TenantsProvider : ITenantsProvider
{
    private readonly IReadOnlySet<TenantIdentifier> _tenants;

    public TenantsProvider(IReadOnlyCollection<string> tenants)
    {
        _tenants = tenants
            .Select(t => new TenantIdentifier(t))
            .ToHashSet();
    }

    public IReadOnlyCollection<TenantIdentifier> GetTenants()
    {
        return _tenants;
    }

    public bool TenantExists(TenantIdentifier tenant)
    {
        return _tenants.Contains(tenant);
    }
}

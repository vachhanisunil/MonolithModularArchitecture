﻿namespace SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Settings;

internal sealed record MongoConnectionSettings
{
    public const string ConfigurationSection = "MongoDatabaseConnection";

    public required string ConnectionString { get; init; }
    public int? MaxPoolSize { get; init; }

    public IReadOnlyCollection<MongoDatabaseSettings> Databases { get; init; } = [];
}

﻿namespace SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Settings;

internal sealed record MongoDatabaseSettings
{
    public required string Tenant { get; init; }

    public required string DatabaseName { get; init; }
}

﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;
using SolutionStudio.BuildingBlocks.Abstractions.Models;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Abstractions;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Settings;

namespace SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Services;

internal sealed class MongoDatabaseProvider : IMongoDatabaseProvider
{
    private readonly IMongoClient _mongoClient;
    private readonly IReadOnlyDictionary<TenantIdentifier, string> _tenantDatabaseNames;

    public MongoDatabaseProvider(
        IMongoClient mongoClient,
        IOptions<MongoConnectionSettings> mongoConnectionSettings
    )
    {
        _mongoClient = mongoClient;
        _tenantDatabaseNames = mongoConnectionSettings.Value
            .Databases
            .ToDictionary(
                db => new TenantIdentifier(db.Tenant),
                db => db.DatabaseName
            );
    }

    public IMongoDatabase GetMongoDatabase(TenantIdentifier tenant)
    {
        if (!_tenantDatabaseNames.TryGetValue(tenant, out string? databaseName))
        {
            throw new SolutionStudioConfigurationException($"Database name could not be found for tenant '{tenant}'.");
        }

        return _mongoClient.GetDatabase(databaseName);
    }
}

﻿using MongoDB.Driver;
using SolutionStudio.BuildingBlocks.Abstractions.Models;

namespace SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Abstractions;

public interface IMongoDatabaseProvider
{
    IMongoDatabase GetMongoDatabase(TenantIdentifier tenant);
}

﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Bson.Serialization.Serializers;
using MongoDB.Driver;
using SolutionStudio.BuildingBlocks.Abstractions.Context;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Abstractions;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Services;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Settings;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMongoDbInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddMongoClient();
        services.AddScoped<IMongoDatabaseProvider, MongoDatabaseProvider>();

        RegisterMongoConventions();

        services.Configure<MongoConnectionSettings>(configuration.GetSection(MongoConnectionSettings.ConfigurationSection));

        return services;
    }

    public static IServiceCollection AddScopedWithMongoDatabase<TService, TImplementation>(this IServiceCollection services)
        where TService : class
        where TImplementation : class, TService
    {
        services.AddScoped<TService>(sp =>
        {
            var userTenantContext = sp.GetRequiredService<IUserTenantContext>();
            var mongoDatabaseProvider = sp.GetRequiredService<IMongoDatabaseProvider>();

            var mongoDatabase = mongoDatabaseProvider.GetMongoDatabase(userTenantContext.Tenant);
            return ActivatorUtilities.CreateInstance<TImplementation>(sp, mongoDatabase);
        });

        return services;
    }

    private static IServiceCollection AddMongoClient(this IServiceCollection services)
    {
        services.AddScoped<IMongoClient>(sp =>
            {
                var mongoConnectionSettings = sp.GetRequiredService<IOptions<MongoConnectionSettings>>().Value;

                var urlBuilder = new MongoUrlBuilder(mongoConnectionSettings.ConnectionString)
                {
                    MaxConnectionPoolSize = mongoConnectionSettings.MaxPoolSize ?? 100
                };

                return new MongoClient(urlBuilder.ToMongoUrl());
            }
        );

        return services;
    }

    private static void RegisterMongoConventions()
    {
        var camelCaseConventionPack = new ConventionPack
        {
            new CamelCaseElementNameConvention()
        };
        ConventionRegistry.Register("camelCase", camelCaseConventionPack, _ => true);

        BsonSerializer.RegisterSerializer(new GuidSerializer(GuidRepresentation.Standard));
    }
}

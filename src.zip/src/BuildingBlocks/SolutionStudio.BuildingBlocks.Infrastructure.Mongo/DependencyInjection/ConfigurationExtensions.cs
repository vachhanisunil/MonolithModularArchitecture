﻿using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;
using SolutionStudio.BuildingBlocks.Infrastructure.Mongo.Settings;

namespace Microsoft.Extensions.Configuration;

internal static class ConfigurationExtensions
{
    public static MongoConnectionSettings GetMongoConnectionSettings(this IConfiguration configuration)
    {
        return configuration
            .GetSection(MongoConnectionSettings.ConfigurationSection)
            .Get<MongoConnectionSettings>()
               ?? throw new SolutionStudioConfigurationException("MongoDb connection is not configured.");
    }
}

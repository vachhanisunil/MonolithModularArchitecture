﻿using System.Net.Http.Headers;

namespace Microsoft.AspNetCore.Http;

public static class HttpRequestExtensions
{
    public static string? GetBearerToken(this HttpRequest httpRequest)
    {
        if (AuthenticationHeaderValue.TryParse(httpRequest.Headers.Authorization, out var headerValue) &&
            headerValue.Scheme.Equals("Bearer", StringComparison.OrdinalIgnoreCase))
        {
            return headerValue.Parameter;
        }

        return null;
    }
}

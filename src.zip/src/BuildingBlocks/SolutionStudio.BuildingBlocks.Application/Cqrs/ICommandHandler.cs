﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

namespace SolutionStudio.BuildingBlocks.Application.Cqrs;

public interface ICommandHandler<in TCommand> where TCommand : ICommand
{
    Task HandleCommandAsync(TCommand command);
}

public interface ICommandHandler<in TCommand, TResponse> where TCommand : ICommand<TResponse>
{
    Task<TResponse> HandleCommandAsync(TCommand command);
}
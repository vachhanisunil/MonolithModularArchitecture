﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

namespace SolutionStudio.BuildingBlocks.Application.Cqrs;

public interface IEventHandler<in TEvent> where TEvent : IEvent
{
    Task HandleEventAsync(IEvent @event);
}
﻿using SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

namespace SolutionStudio.BuildingBlocks.Application.Cqrs;

public interface IQueryHandler<in TQuery, TResponse> where TQuery : IQuery<TResponse>
{
    Task<TResponse> HandleQueryAsync(TQuery query);
}
using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace SolutionStudio.BuildingBlocks.Application.Exceptions;

public class SolutionStudioAuthorizationException : SolutionStudioException
{
    public SolutionStudioAuthorizationException(string message) : base(message)
    {
    }
}

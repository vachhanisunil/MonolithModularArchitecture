﻿using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace SolutionStudio.BuildingBlocks.Application.Exceptions;

public class SolutionStudioNotFoundException : SolutionStudioException
{
    public SolutionStudioNotFoundException(string message) : base(message)
    {
    }
}
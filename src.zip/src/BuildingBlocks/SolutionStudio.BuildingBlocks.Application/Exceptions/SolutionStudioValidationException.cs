using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace SolutionStudio.BuildingBlocks.Application.Exceptions;

public class SolutionStudioValidationException : SolutionStudioException
{
    public SolutionStudioValidationException(string message) : base(message)
    {
    }
}
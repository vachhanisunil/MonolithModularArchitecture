﻿using SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

namespace SolutionStudio.BuildingBlocks.Application.Exceptions;

public class SolutionStudioInternalValidationException : SolutionStudioException
{
    public SolutionStudioInternalValidationException(string message) : base(message)
    {
    }
}
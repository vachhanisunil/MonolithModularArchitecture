﻿namespace SolutionStudio.BuildingBlocks.Facade.RequestModels;

public static class FieldLengthLimit
{
    public const int Short = 100;
    public const int Medium = 500;
    public const int Long = 2000;
    public const int MaxValue = int.MaxValue;
}

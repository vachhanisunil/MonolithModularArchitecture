using Microsoft.AspNetCore.Authorization;

namespace SolutionStudio.BuildingBlocks.Facade.Security.Authorization;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class TenantAdminAuthorizeAttribute : AuthorizeAttribute
{
    public TenantAdminAuthorizeAttribute()
    {
        Roles = AuthorizationRoles.TenantAdmin;
    }
}

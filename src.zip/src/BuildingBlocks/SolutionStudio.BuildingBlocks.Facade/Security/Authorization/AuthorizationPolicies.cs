namespace SolutionStudio.BuildingBlocks.Facade.Security.Authorization;

public static class AuthorizationPolicies
{
    public const string TenantAuthorizationPolicy = "TenantAuthorizationPolicy";
}

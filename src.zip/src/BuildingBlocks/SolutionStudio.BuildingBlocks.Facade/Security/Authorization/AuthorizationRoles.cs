namespace SolutionStudio.BuildingBlocks.Facade.Security.Authorization;

public static class AuthorizationRoles
{
    public const string TenantAdmin = "SolutionStudioTenantAdmin";

    public static IReadOnlyCollection<string> AllRoles { get; } =
    [
        TenantAdmin,
    ];
}

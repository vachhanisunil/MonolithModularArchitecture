namespace SolutionStudio.BuildingBlocks.Abstractions.Models;

/// <summary>
/// Although it might be tempting to convert this to a record, doing so would require derived classes to redefine ToString()
/// as records implement their own ToString() method.
/// By keeping it as class, we avoid it.
/// </summary>
public abstract class CaseInsensitiveString : IEquatable<CaseInsensitiveString>, IEquatable<string>
{
    protected string Value { get; }

    protected CaseInsensitiveString(string value)
    {
        Value = value.Trim();
    }

    public bool Equals(CaseInsensitiveString? other)
    {
        return other is not null && Equals(other.Value);
    }

    public override bool Equals(object? obj)
    {
        return Equals(obj as CaseInsensitiveString);
    }

    public bool Equals(string? other)
    {
        return other is not null && string.Equals(Value, other, StringComparison.OrdinalIgnoreCase);
    }

    public override int GetHashCode()
    {
        return StringComparer.OrdinalIgnoreCase.GetHashCode(Value);
    }

    public override string ToString()
    {
        return Value;
    }

    public static bool operator ==(CaseInsensitiveString? left, CaseInsensitiveString? right)
    {
        if (left is null)
        {
            return right is null;
        }

        return left.Equals(right);
    }

    public static bool operator !=(CaseInsensitiveString? left, CaseInsensitiveString? right)
    {
        return !(left == right);
    }
}
namespace SolutionStudio.BuildingBlocks.Abstractions.Models;

public sealed class TenantIdentifier : CaseInsensitiveString
{
    public TenantIdentifier(string tenant) : base(tenant) { }

    public static implicit operator TenantIdentifier(string value)
    {
        return new TenantIdentifier(value);
    }

    public static implicit operator string(TenantIdentifier identifier)
    {
        return identifier.Value;
    }
}
﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Context;

public interface IAdminUserContext
{
    bool IsTenantAdmin();
}

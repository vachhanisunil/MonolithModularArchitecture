namespace SolutionStudio.BuildingBlocks.Abstractions.Context;

public interface IUserContext : IUserTenantContext
{
    string UserName { get; }
    string FullUserName { get; }
    string? Email { get; }
    string? Language { get; }
}
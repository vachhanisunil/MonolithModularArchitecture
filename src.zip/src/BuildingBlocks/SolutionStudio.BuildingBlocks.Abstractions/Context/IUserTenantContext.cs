using SolutionStudio.BuildingBlocks.Abstractions.Models;

namespace SolutionStudio.BuildingBlocks.Abstractions.Context;

public interface IUserTenantContext
{
    public TenantIdentifier Tenant { get; }
    public string ClientId { get; }
}
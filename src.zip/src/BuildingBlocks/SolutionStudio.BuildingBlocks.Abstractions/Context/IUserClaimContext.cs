namespace SolutionStudio.BuildingBlocks.Abstractions.Context;

public interface IUserClaimContext
{
    string GetRequiredClaimValue(string claimType);
}

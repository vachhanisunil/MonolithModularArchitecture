﻿using SolutionStudio.BuildingBlocks.Abstractions.Models;

namespace SolutionStudio.BuildingBlocks.Abstractions.Services;

public interface ITenantsProvider
{
    IReadOnlyCollection<TenantIdentifier> GetTenants();
    bool TenantExists(TenantIdentifier tenant);
}
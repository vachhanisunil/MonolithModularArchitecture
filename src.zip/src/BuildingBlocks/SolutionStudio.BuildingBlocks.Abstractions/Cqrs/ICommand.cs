﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

public interface ICommand
{
}

public interface ICommand<out TResponse>
{
}
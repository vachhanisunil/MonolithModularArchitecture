﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

public interface IQuery<out TResponse>
{
}
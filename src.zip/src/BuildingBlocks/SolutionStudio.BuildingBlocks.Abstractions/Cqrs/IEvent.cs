﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Cqrs;

public interface IEvent
{
}
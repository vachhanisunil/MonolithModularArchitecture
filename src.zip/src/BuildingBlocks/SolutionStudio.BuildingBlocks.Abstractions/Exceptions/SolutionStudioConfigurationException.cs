namespace SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

public class SolutionStudioConfigurationException : SolutionStudioException
{
    public SolutionStudioConfigurationException(string message) : base(message)
    {
    }
}
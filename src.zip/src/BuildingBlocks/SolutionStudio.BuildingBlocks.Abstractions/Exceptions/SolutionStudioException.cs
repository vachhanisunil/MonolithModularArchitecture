﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

public abstract class SolutionStudioException : Exception
{
    protected SolutionStudioException(string message) : base(message)
    {
    }

    protected SolutionStudioException(string message, Exception? innerException) : base(message, innerException)
    {
    }
}
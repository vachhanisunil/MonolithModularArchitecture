﻿namespace SolutionStudio.BuildingBlocks.Abstractions.Exceptions;

public class SolutionStudioInternalException : SolutionStudioException
{
    public SolutionStudioInternalException(string message) : base(message)
    {
    }

    public SolutionStudioInternalException(string message, Exception? innerException) : base(message, innerException)
    {
    }
}